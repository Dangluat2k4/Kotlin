package vn.poly.mob305.myapplication

import android.os.Bundle
import androidx.activity.compose.setContent
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import coil.compose.AsyncImage
import vn.poly.mob305.myapplication.databinding.ActivityMainBinding

class MainActivity2 : AppCompatActivity() {

    data class Cats(val id: Int, val Name: String, val des: String, val Image: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // khai bao bien nhan gia tri cua mang
        var listCast = listOf(
            Cats(
                1,
                "meo map",
                "meo khong long",
                "https://th.bing.com/th/id/OIP.kp8cgwjkuj2cqMF71u93MAHaEK?w=277&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
            ),
            Cats(
                1,
                "meo map",
                "meo khong long",
                "https://th.bing.com/th/id/OIP.UHbamC08Q2Aa6GbBqnJilAHaFk?w=199&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
            ),
            Cats(
                1,
                "meo map",
                "meo khong long",
                "https://th.bing.com/th/id/OIP.Si4ivaE9XuP2QcWAf5YVPAHaE9?w=259&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7"
            ),
        )
        setContent {

            var castSelect = remember {
                mutableStateOf<Cats?>(null)
            }

            var listStateCatS = remember {
                mutableStateListOf(*listCast.toTypedArray())
            }

            LazyColumn {
                itemsIndexed(listStateCatS) { i, it ->
                    Column {
                        Button(onClick = {
                            castSelect.value = it
                        }) {
                            Text(text = "Detail")
                        }

                        Button(onClick = {
                            listStateCatS.remove(it)

                        }) {
                            Text(text = "Delete")
                        }

                        Text(text = "id : ${it.id}")
                        Text(text = "Name : ${it.Name}")
                        Text(text = "Des : ${it.des}")

                        AsyncImage(
                            modifier = Modifier.size(90.dp, 90.dp),
                            model = "${it.Image}",
                            contentDescription = "null"
                        )
                    }
                }
            }

            castSelect.value?.let {
                Dialog(onDismissRequest = { castSelect.value == null }) {
                    Column {
                        Text(text = "${castSelect.value?.des}" )
                        Text(text = "${castSelect.value?.Name}" )
                        AsyncImage(modifier = Modifier.size(90.dp, 90.dp),
                            model = "${it.Image}",
                            contentDescription ="" )
                    }

                }
            }
        }
    }

}