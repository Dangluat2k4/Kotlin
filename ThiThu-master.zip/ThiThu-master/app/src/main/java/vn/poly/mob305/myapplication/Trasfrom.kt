package vn.poly.mob305.myapplication

fun CatResponse.toCat(): MainActivity3.Cats {
    return MainActivity3.Cats(
        _id = this._id,
        mimetype = this.mimetype,
        size = this.size,
        tags = this.tags
    )
}