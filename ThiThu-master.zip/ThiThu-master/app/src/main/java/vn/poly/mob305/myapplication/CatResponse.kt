package vn.poly.mob305.myapplication

import com.google.gson.annotations.SerializedName

data class CatResponse(
    @SerializedName("_id") var _id: String,
    @SerializedName("mimetype") var mimetype: String,
    @SerializedName("size") var size: Int,
    @SerializedName("tags") var tags: List<String>,
)