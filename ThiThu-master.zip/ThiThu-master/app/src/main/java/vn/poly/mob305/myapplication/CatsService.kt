package vn.poly.mob305.myapplication

import retrofit2.Response
import retrofit2.http.GET

interface CatsService {
    @GET("cats?tags=cute&skip=0&limit=10")
    suspend fun getListCat(): Response<List<CatResponse>>
}
