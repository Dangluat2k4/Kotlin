package vn.poly.mob305.myapplication

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class CatViewModel : ViewModel() {
    private val _cats = MutableLiveData<List<MainActivity3.Cats>>()
    val cats: LiveData<List<MainActivity3.Cats>> = _cats

    init {
        getCats()
    }

    fun getCats() {
        viewModelScope.launch {
            try {
                var response = RetrofitService().catsService.getListCat()
                if (response.isSuccessful) {
                    _cats.postValue(response.body()?.map { it.toCat() })
                } else {
                    _cats.postValue(emptyList())
                }
            } catch (e: Exception) {
                Log.e("Tag", "getCats" + e.message)
                _cats.postValue(emptyList())
            }
        }
    }

    fun deleteCat(cat : MainActivity3.ListCat){
        _cats.value = _cats.value?.filter { it._id != cat._id }
    }

    fun updateCat(updatedCat: MainActivity3.ListCat) {
        _cats.value = _cats.value?.map {
            if (it._id == updatedCat._id) {
                it.copy(size = updatedCat.size, tags = updatedCat.tags)
            } else {
                it
            }
        }
    }

    fun addNewCat(addCat : MainActivity3.ListCat){
        val currentCats  = _cats.value ?.toMutableList() ?: mutableListOf()
        currentCats.add(addCat.toCats())
        _cats.value = currentCats
    }
}

private fun MainActivity3.ListCat.toCats(): MainActivity3.Cats {
    return MainActivity3.Cats(
        _id = this._id,
        mimetype = this.mimetype,
        size = this.size,
        tags = this.tags
    )
}