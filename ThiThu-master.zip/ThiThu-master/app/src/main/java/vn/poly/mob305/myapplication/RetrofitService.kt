package vn.poly.mob305.myapplication

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

open class RetrofitService {
    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://cataas.com/api/")  // Chỉ cần base URL
        .addConverterFactory(GsonConverterFactory.create())  // Thêm Converter Factory nếu cần
        .build()

    val catsService: CatsService by lazy {
        retrofit.create(CatsService::class.java)
    }
}
