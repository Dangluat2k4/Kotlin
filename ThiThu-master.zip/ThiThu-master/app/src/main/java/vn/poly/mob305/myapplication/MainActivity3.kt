package vn.poly.mob305.myapplication

import android.os.Bundle
import android.os.Debug
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.setContent
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import coil.compose.rememberImagePainter
import vn.poly.mob305.myapplication.databinding.ActivityMain2Binding


class MainActivity3 : AppCompatActivity() {

    data class Cats(
        val _id: String,
        val mimetype: String,
        val size: Int,
        val tags: List<String>,
    )


    data class ListCat(
        val _id: String,
        val mimetype: String,
        val size: Int,
        val tags: List<String>,
    )

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContent {
            MainCast(CatViewModel())
        }
    }

    @Composable
    fun MainCast(catModel: CatViewModel) {
        var showAddDialog by remember { mutableStateOf(false) }
        val catsls = catModel.cats.observeAsState(initial = emptyList())
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(catsls.value.size) { catsRow ->
                Column {
                    val dsCat = catsls.value[catsRow]
                    CatsItem(catsls.value[catsRow], catModel)

                    listCat(dsCat.toListCat(), catModel)
                }
            }
        }
        Button(onClick = { showAddDialog = true }) {
            Text(text = "Add New Cat")
        }
        if (showAddDialog) {
            AddCatDiaLog(catViewModel = catModel, onDismiss = { showAddDialog = false })
        }
    }


    @Composable
    fun CatsItem(cat: MainActivity3.Cats, catViewModel: CatViewModel) {
        val context = LocalContext.current
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = rememberImagePainter("https://cataas.com/cat/${cat._id}"), // Thay URL này bằng URL hình ảnh trực tuyến của bạn
                    contentDescription = null,
                    modifier = Modifier
                        .width(100.dp)
                        .height(100.dp)
                        .align(Alignment.CenterHorizontally)
                )
            }

            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "size: ${cat.size}")
            }

            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "tags: ${cat.tags}")
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun listCat(listCat: ListCat, catViewModel: CatViewModel) {
        val context = LocalContext.current
        var size by remember { mutableStateOf(listCat.size.toString()) }
        var tags by remember { mutableStateOf(listCat.tags.joinToString(", ")) }
        var showDiaLog by remember {
            mutableStateOf(false)
        }
        var showDiaLogAndUD by remember {
            mutableStateOf(false)
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = rememberImagePainter("https://cataas.com/cat/${listCat._id}"),
                    contentDescription = null,
                    modifier = Modifier
                        .width(100.dp)
                        .height(100.dp)
                        .clickable { showDiaLog = true }
                        .align(Alignment.CenterHorizontally)
                )
            }

            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "size: ${listCat.size}")
            }

            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "tags: ${listCat.tags}")
            }
            Column {
                Button(onClick = { catViewModel.deleteCat(listCat) }) {
                    Text(text = "Delete")
                }
            }
            Column {
                Button(onClick = { showDiaLogAndUD = true }) {
                    Text(text = "Update")
                }
            }
            Column {
                Button(onClick = { }) {

                }
            }
        }

        if (showDiaLog) {
            AlertDialog(onDismissRequest = { showDiaLog = false },
                title = {
                    Text(text = " chi tiet")
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = rememberImagePainter("https://cataas.com/cat/${listCat._id}"),
                            contentDescription = null,
                            modifier = Modifier
                                .width(100.dp)
                                .height(100.dp),
                            alignment = Alignment.Center
                        )
                        Column(
                            modifier = Modifier.width(100.dp)
                        ) {
                            Text(text = "size: ${listCat.size}")
                        }

                        Column(
                            modifier = Modifier.width(100.dp),
                        ) {
                            Text(text = "tags: ${listCat.tags}")
                        }
                    }

                },

                confirmButton = {
                    TextButton(onClick = { showDiaLog = false })
                    {
                        Text(text = "false")
                    }
                })
        }

        if (showDiaLogAndUD) {
            AlertDialog(onDismissRequest = { showDiaLogAndUD = false },
                title = {
                    Text(text = " chi tiet")
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = rememberImagePainter("https://cataas.com/cat/${listCat._id}"),
                            contentDescription = null,
                            modifier = Modifier
                                .width(100.dp)
                                .height(100.dp),
                            alignment = Alignment.Center
                        )
                        Column(
                            modifier = Modifier.width(100.dp)
                        ) {
                            TextField(
                                value = size,
                                onValueChange = { size = it },
                                label = { Text("Size") }
                            )
                        }

                        Column(
                            modifier = Modifier.width(100.dp),
                        ) {
                            TextField(
                                value = tags,
                                onValueChange = { tags = it },
                                label = { Text("Tags") }
                            )
                        }
                    }

                },

                confirmButton = {
                    TextButton(onClick = {
                        showDiaLogAndUD = false
                        catViewModel.updateCat(
                            listCat.copy(
                                size = size.toIntOrNull() ?: listCat.size,
                                tags = tags.split(", ").map { it.trim() }
                            )
                        )
                    }) {
                        Text(text = "Update")
                    }
                })
        }
    }

    @Composable
    private fun Cats.toListCat(): ListCat {
        return ListCat(
            _id = this._id,
            mimetype = this.mimetype,
            size = this.size,
            tags = this.tags
        )
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun AddCatDiaLog(catViewModel: CatViewModel, onDismiss: () -> Unit) {
        var _id by remember {
            mutableStateOf("")
        }
        var minetype by remember {
            mutableStateOf("")
        }
        var size by remember {
            mutableStateOf("")
        }
        var tags by remember {
            mutableStateOf("")
        }


        AlertDialog(onDismissRequest = { onDismiss() },

            title = { Text(text = "Add new cats") },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TextField(value = _id,
                        onValueChange = { _id = it },
                        label = { Text(text = "ID") }
                    )
                    TextField(value = minetype,
                        onValueChange = { minetype = it },
                        label = { Text(text = "Mubetype") }
                    )
                    TextField(value = size,
                        onValueChange = { size = it },
                        label = { Text(text = "Size") }
                    )
                    TextField(value = tags,
                        onValueChange = { tags = it },
                        label = { Text(text = "tags") }
                    )
                }
            },


            confirmButton = {
                TextButton(onClick = {
                    val newCat = ListCat(
                        _id = _id,
                        mimetype = minetype,
                        size = size.toIntOrNull() ?: 9,
                        tags = tags.split(",").map { it.trim() })
                    catViewModel.addNewCat(newCat)
                    onDismiss()
                })
                {
                    Text(text = "Add New Car")
                }
            })
    }
}

