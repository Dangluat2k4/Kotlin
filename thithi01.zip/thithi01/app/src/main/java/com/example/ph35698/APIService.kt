package com.example.ph35698

import retrofit2.Response
import retrofit2.http.GET

interface APIService{
    @GET("https://restcountries.com/v3.1/all/")
    suspend fun getListAPI() : Response<List<APIRespone>>
}