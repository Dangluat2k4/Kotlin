package com.example.ph35698

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {

    data class API(
        val name: Name,
        val flags: Flags,
    )
    data class APICL(
        val name: Name,
        val flags: Flags,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MainAPI(APIViewModel())
        }
    }


    @Composable
    fun MainAPI(apiModel: APIViewModel) {

        val listAPI = apiModel.api.observeAsState(initial = emptyList())

        Spacer(modifier = Modifier.height(10.dp))
        Column(
            Modifier
                .fillMaxWidth()
                .padding(50.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp), // Ensure some spacing between Button and Grid
                contentPadding = PaddingValues(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listAPI.value.size) { APIRow ->
                    Column(
                        modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        val dsAPI = listAPI.value[APIRow]
                        APIItem(dsAPI.toListAPI(),apiModel)
                //        APIItem(listAPI.value[APIRow],apiModel)
                    }
                }
            }
        }
    }


    @Composable
    fun APIItem(api: APICL, apiViewModel: APIViewModel) {

        var SDialog by remember {
            mutableStateOf(false)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.width(100.dp),
                verticalArrangement = Arrangement.Center
            ) {
                AsyncImage(
                    model = api.flags.png, contentDescription = null,
                    modifier = Modifier
                        .size(100.dp)
                        .clickable { SDialog = true }
                )
            }
            Spacer(modifier = Modifier.height(10.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(text = "Name : ${api.name.common}", textAlign = TextAlign.Center)
            }

        }
        Spacer(modifier = Modifier.height(5.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.Center
        ) {
            Button(onClick = {apiViewModel.deleteCat(api)}) {
                Text(text = "Delete")
            }
        }

        if (SDialog) {
            AlertDialog(onDismissRequest = { SDialog = true },
                title = {
                    Text(text = "chi tiet")
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    )

                    {
                        AsyncImage(
                            model = api.flags.png, contentDescription = "",
                            modifier = Modifier
                                .size(250.dp)
                        )
                        Column(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "Name :" + api.name)
                        }
                    }

                },


                confirmButton = {
                    TextButton(onClick = { SDialog = false }) {
                        Text(text = "close")
                    }
                })
        }


    }

    @Composable
    private fun API.toListAPI(): APICL {
        return APICL(
            name = this.name,
            flags = this.flags,
        )
    }


}