package com.example.ph35698

import com.google.gson.annotations.SerializedName


data class APIRespone(
    @SerializedName("name") val  name :Name,
    @SerializedName("flags") val  flags : Flags,
)

data class Name(
    @SerializedName("common") val common: String,
    @SerializedName("official") val official: String,
    @SerializedName("nativeName") val nativeName: NativeName
)
data class NativeName(
    @SerializedName("fra") val fra: Fra
)
data class Fra(
    @SerializedName("official") val official: String,
    @SerializedName("common") val common: String
)
data class Flags(
    @SerializedName("svg") val svg: String,
    @SerializedName("png") val png: String
)