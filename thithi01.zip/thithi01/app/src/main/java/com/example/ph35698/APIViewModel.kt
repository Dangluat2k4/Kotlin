package com.example.ph35698

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class APIViewModel : ViewModel() {
    private val _api = MutableLiveData<List<MainActivity.API>>()
    val api: LiveData<List<MainActivity.API>> = _api

    init {
        getAPI()
    }

    fun getAPI() {
        viewModelScope.launch {
            try {
                var response = APIRetrofitService().apiService.getListAPI()
                if (response.isSuccessful) {
                    _api.postValue(response.body()?.map { it.toAPI() })
                } else {
                    _api.postValue(emptyList())
                    Log.e("Tag", "getCastsssssssssssssssssss")
                }
            } catch (e: Exception) {
                Log.e("Tag", "getCast" + e.message)
            }
        }
    }

    fun deleteCat(api: MainActivity.APICL) {
        _api.value = _api.value?.filter { it.name != api.name }
    }
}