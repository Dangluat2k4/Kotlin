package com.example.ph35698

fun APIRespone.toAPI(): MainActivity.API {
    return MainActivity.API(
         name = this.name,
        flags = this.flags
    )
}