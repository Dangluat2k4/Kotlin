package com.example.ph35698

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

open class APIRetrofitService {
    private var retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://restcountries.com/v3.1/all/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val apiService: APIService by lazy {
        retrofit.create(APIService::class.java)
    }
}